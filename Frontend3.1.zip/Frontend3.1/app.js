/*const express = require('express');
const path = require('path');
const app = express();
const port = 3000;

// Set the view engine to ejs
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Serve static files (CSS, images, etc.)
app.use(express.static(path.join(__dirname, 'public')));

// Routes for different pages
app.get('/', (req, res) => res.render('index'));
app.get('/customers', (req, res) => res.render('customers', { customers: mockCustomers }));
app.get('/products', (req, res) => res.render('products', { products: mockProducts }));
app.get('/orders', (req, res) => res.render('orders', { orders: mockOrders }));
app.get('/product-reviews', (req, res) => res.render('product_reviews', { productReviews: mockProductReviews }));
app.get('/order-items', (req, res) => res.render('order_items', { orderItems: mockOrderItems }));
app.get('/addresses', (req, res) => res.render('addresses', { addresses: mockAddresses }));
app.get('/inventory', (req, res) => res.render('inventory', { inventoryItems: mockInventory }));

// Mock data for customers
const mockCustomers = [
  { CustomerID: 1, LastName: 'Smith', FirstName: 'John', Email: 'john@example.com', Address: '123 Main St' },
  // Add more customers as needed
];

// Mock data for products
const mockProducts = [
  { ProductID: 1, Name: 'Laptop', Description: 'High-performance laptop', Price: 1000, Category: 'Electronics' },
  // Add more products as needed
];

// Mock data for orders
const mockOrders = [
  { OrderID: 1, CustomerID: 1, OrderDate: '2023-01-01', ShipDate: '2023-01-05', ShipCity: 'New York', ShipState: 'NY', ShipZip: '10001', ShipCost: 50, Status: 'Shipped' },
  // Add more orders as needed
];

// Mock data for product reviews
const mockProductReviews = [
  { ReviewID: 1, CustomerID: 1, ProductID: 1, rating: 5 },
  // Add more product reviews as needed
];

// Mock data for order items
const mockOrderItems = [
  { OrderItemID: 1, OrderID: 1, ProductID: 1, Quantity: 2, PaymentType: 'Credit Card' },
  // Add more order items as needed
];

// Mock data for addresses
const mockAddresses = [
  { AddressID: 1, CustomerID: 1, Address: '123 Main St', City: 'New York', State: 'NY', ZipCode: '10001' },
  // Add more addresses as needed
];

// Mock data for inventory
const mockInventory = [
  { InventoryID: 1, Quantity: 10, Description: 'Laptops in stock' },
  // Add more inventory items as needed
];

app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});


// import the oracledb module and set up the database connection configuration
const oracledb = require('oracledb');

const dbConfig = {
  user: 'username',
  password: 'password',
  connectString: 'localhost/XEPDB1' // Adjust this to your Oracle connection string
};
*/

const express = require('express');
const path = require('path');
const oracledb = require('oracledb');
const app = express();
const port = 3000;

// Set the view engine to ejs
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Serve static files (CSS, images, etc.)
app.use(express.static(path.join(__dirname, 'public')));

// Parse incoming URL-encoded form data
app.use(express.urlencoded({ extended: true }));

// Oracle DB Configuration
const dbConfig = {
  user: 'COMP214_M23_zo_1',
  password: 'password',
  connectString: '199.212.26.208:1521/SQLD' // Adjust this to your Oracle connection string
};

// Example route to fetch products from Oracle DB
//-------------------------------------------
// Show Addresses
app.get('/addresses', async (req, res) => {
    let connection;
  
    try {
      connection = await oracledb.getConnection(dbConfig);
      const result = await connection.execute('SELECT * FROM address'); // Note the change here
  
      res.render('addresses', { addresses: result.rows });
    } catch (err) {
      console.error(err);
      res.status(500).send('Error fetching addresses');
    } finally {
      if (connection) {
        try {
          await connection.close();
        } catch (err) {
          console.error(err);
        }
      }
    }
  });

// Insert Address
app.post('/addresses', async (req, res) => {
  // Extract data from the request
  const { customerId, address, city, state, zip } = req.body;
  let connection;

  try {
    connection = await oracledb.getConnection(dbConfig);
    await connection.execute(
      'INSERT INTO Address (AddressId, CustomerId, Address, City, State, Zip) VALUES (addressid_seq.NEXTVAL, :customerId, :address, :city, :state, :zip)',
      [customerId, address, city, state, zip],
      { autoCommit: true }
    );
    res.redirect('/addresses');
  } catch (err) {
    console.error(err);
    res.status(500).send('Error adding address');
  } finally {
    if (connection) await connection.close();
  }
});
  
// Update Address
app.post('/addresses/update/:addressId', async (req, res) => {
  const addressId = req.params.addressId;
  const { customerId, address, city, state, zip } = req.body;

  let connection;
  try {
    connection = await oracledb.getConnection(dbConfig);
    const query = `
      UPDATE Address
      SET CustomerId = :customerId,
          Address = :address,
          City = :city,
          State = :state,
          Zip = :zip
      WHERE AddressId = :addressId
    `;
    const binds = { customerId, address, city, state, zip, addressId };
    const result = await connection.execute(query, binds, { autoCommit: true });

    if (result.rowsAffected > 0) {
      console.log('Address updated successfully.');
      res.redirect('/addresses');
    } else {
      console.log('Address not found.');
      res.status(404).send('Address not found');
    }
  } catch (err) {
    console.error('Error updating address:', err);
    res.status(500).send('Error updating address');
  } finally {
    if (connection) {
      try {
        await connection.close();
      } catch (err) {
        console.error(err);
      }
    }
  }
});

// Delete Address
app.post('/addresses/delete/:id', async (req, res) => {
  const addressId = req.params.id;
  let connection;

  try {
    connection = await oracledb.getConnection(dbConfig);
    await connection.execute(
      'DELETE FROM Address WHERE AddressId = :id',
      [addressId],
      { autoCommit: true }
    );
    res.redirect('/addresses');
  } catch (err) {
    console.error(err);
    res.status(500).send('Error deleting address');
  } finally {
    if (connection) {
      try {
        await connection.close();
      } catch (err) {
        console.error(err);
      }
    }
  }
});


//--------------------------------------------------
// Show customers
app.get('/customers', async (req, res) => {
  let connection;

  try {
    connection = await oracledb.getConnection(dbConfig);
    const result = await connection.execute('SELECT * FROM customer', [], { fetchArraySize: 1000 });

    res.render('customers', { customers: result.rows });
  } catch (err) {
    console.error(err);
    res.status(500).send('Error fetching customers');
  } finally {
    if (connection) {
      try {
        await connection.close();
      } catch (err) {
        console.error(err);
      }
    }
  }
});

// Insert Customer
app.post('/addresses', async (req, res) => {
  // Extract data from the request
  const { customerId, address, city, state, zip } = req.body;
  let connection;

  try {
    connection = await oracledb.getConnection(dbConfig);
    await connection.execute(
      'INSERT INTO Address (AddressId, CustomerId, Address, City, State, Zip) VALUES (addressid_seq.NEXTVAL, :customerId, :address, :city, :state, :zip)',
      [customerId, address, city, state, zip],
      { autoCommit: true }
    );
    res.redirect('/addresses');
  } catch (err) {
    console.error(err);
    res.status(500).send('Error adding address');
  } finally {
    if (connection) await connection.close();
  }
});


// Update Customer
app.post('/customers/update/:customerId', async (req, res) => {
  const { customerId, firstName, lastName, email, password, securityQuestion, securityAnswer } = req.body;

  let connection;
  try {
    connection = await oracledb.getConnection(dbConfig);
    const query = `
      UPDATE Customer
      SET FirstName = :firstName,
          LastName = :lastName,
          Email = :email,
          Password = :password,
          SecurityQuestion = :securityQuestion,
          SecurityAnswer = :securityAnswer
      WHERE CustomerId = :customerId
    `;
    const binds = { customerId: Number(customerId), firstName, lastName, email, password, securityQuestion, securityAnswer };
    const result = await connection.execute(query, binds, { autoCommit: true });

    if (result.rowsAffected > 0) {
      console.log('Customer updated successfully.');
      res.redirect('/customers');
    } else {
      console.log('Customer not found.');
      res.status(404).send('Customer not found');
    }
  } catch (err) {
    console.error('Error updating customer:', err);
    res.status(500).send('Error updating customer');
  } finally {
    if (connection) {
      try {
        await connection.close();
      } catch (err) {
        console.error(err);
      }
    }
  }
});



// Delete Customer
app.post('/customers/delete/:id', async (req, res) => {
  const customerId = req.params.id;
  let connection;

  try {
    connection = await oracledb.getConnection(dbConfig);
    await connection.execute(
      'DELETE FROM Customer WHERE CustomerId = :id',
      [customerId],
      { autoCommit: true }
    );
    res.redirect('/customers');
  } catch (err) {
    console.error(err);
    res.status(500).send('Error deleting customer');
  } finally {
    if (connection) {
      try {
        await connection.close();
      } catch (err) {
        console.error(err);
      }
    }
  }
});

//---------------------------------------------------
// Show inventory
app.get('/inventory', async (req, res) => {
  let connection;

  try {
    connection = await oracledb.getConnection(dbConfig);
    const result = await connection.execute('SELECT * FROM Inventory', [], { fetchArraySize: 1000 });
    res.render('inventory', { inventory: result.rows });
  } catch (err) {
    console.error(err);
    res.status(500).send('Error fetching inventory');
  } finally {
    if (connection) {
      try {
        await connection.close();
      } catch (err) {
        console.error(err);
      }
    }
  }
});

// Insert Inventory
app.post('/inventory', async (req, res) => {
  const { productId, quantity, shelvingLocation } = req.body;
  let connection;

  try {
    connection = await oracledb.getConnection(dbConfig);
    await connection.execute(
      'INSERT INTO Inventory (InventoryId, ProductID, Quantity, ShelvingLocation) VALUES (inventoryid_seq.NEXTVAL, :productId, :quantity, :shelvingLocation)',
      [productId, quantity, shelvingLocation],
      { autoCommit: true }
    );
    res.redirect('/inventory');
  } catch (err) {
    console.error(err);
    res.status(500).send('Error adding inventory item');
  } finally {
    if (connection) await connection.close();
  }
});

// Update Inventory
app.post('/inventory/update/:inventoryId', async (req, res) => {
  const inventoryId = req.params.inventoryId;
  const { productId, quantity, shelvingLocation } = req.body;

  let connection;
  try {
    connection = await oracledb.getConnection(dbConfig);
    const query = `
      UPDATE Inventory
      SET ProductID = :productId,
          Quantity = :quantity,
          ShelvingLocation = :shelvingLocation
      WHERE InventoryId = :inventoryId
    `;
    const binds = { productId, quantity: Number(quantity), shelvingLocation, inventoryId: Number(inventoryId) };
    const result = await connection.execute(query, binds, { autoCommit: true });
    
    if (result.rowsAffected > 0) {
      console.log('Inventory item updated successfully.');
      res.redirect('/inventory');
    } else {
      console.log('Inventory item not found.');
      res.status(404).send('Inventory item not found');
    }
  } catch (err) {
    console.error('Error updating inventory item:', err);
    res.status(500).send('Error updating inventory item');
  } finally {
    if (connection) {
      try {
        await connection.close();
      } catch (err) {
        console.error(err);
      }
    }
  }
});

// Delete Inventory
app.post('/inventory/delete/:id', async (req, res) => {
  const inventoryId = req.params.id;
  let connection;

  try {
    connection = await oracledb.getConnection(dbConfig);
    await connection.execute(
      'DELETE FROM Inventory WHERE InventoryId = :id',
      [inventoryId],
      { autoCommit: true }
    );
    res.redirect('/inventory');
  } catch (err) {
    console.error(err);
    res.status(500).send('Error deleting inventory item');
  } finally {
    if (connection) {
      try {
        await connection.close();
      } catch (err) {
        console.error(err);
      }
    }
  }
});

//---------------------------------------------------
// Show OrderItems
app.get('/orderItems', async (req, res) => {
  let connection;

  try {
    connection = await oracledb.getConnection(dbConfig);
    const result = await connection.execute('SELECT * FROM OrderItem');

    res.render('orderItems', { orderItems: result.rows });
  } catch (err) {
    console.error(err);
    res.status(500).send('Error fetching order items');
  } finally {
    if (connection) {
      try {
        await connection.close();
      } catch (err) {
        console.error(err);
      }
    }
  }
});

// Insert OrderItem
app.post('/orderItems', async (req, res) => {
const { orderId, productId, quantity, actualRetail } = req.body;
let connection;

try {
  connection = await oracledb.getConnection(dbConfig);
  await connection.execute(
    'INSERT INTO OrderItem (OrderItemId, OrderId, ProductId, Quantity, ActualRetail) VALUES (orderitemid_seq.NEXTVAL, :orderId, :productId, :quantity, :actualRetail)',
    [orderId, productId, quantity, actualRetail],
    { autoCommit: true }
  );
  res.redirect('/orderItems');
} catch (err) {
  console.error(err);
  res.status(500).send('Error adding order item');
} finally {
  if (connection) await connection.close();
}
});

// Update OrderItem
app.post('/orderItems/update/:orderItemId', async (req, res) => {
const orderItemId = req.params.orderItemId;
const { orderId, productId, quantity, actualRetail } = req.body;

let connection;
try {
  connection = await oracledb.getConnection(dbConfig);
  const query = `
    UPDATE OrderItem
    SET OrderId = :orderId,
        ProductId = :productId,
        Quantity = :quantity,
        ActualRetail = :actualRetail
    WHERE OrderItemId = :orderItemId
  `;
  const binds = { orderId, productId, quantity, actualRetail, orderItemId };
  const result = await connection.execute(query, binds, { autoCommit: true });

  if (result.rowsAffected > 0) {
    console.log('Order item updated successfully.');
    res.redirect('/orderItems');
  } else {
    console.log('Order item not found.');
    res.status(404).send('Order item not found');
  }
} catch (err) {
  console.error('Error updating order item:', err);
  res.status(500).send('Error updating order item');
} finally {
  if (connection) {
    try {
      await connection.close();
    } catch (err) {
      console.error(err);
    }
  }
}
});

// Delete OrderItem
app.post('/orderItems/delete/:id', async (req, res) => {
const orderItemId = req.params.id;
let connection;

try {
  connection = await oracledb.getConnection(dbConfig);
  await connection.execute(
    'DELETE FROM OrderItem WHERE OrderItemId = :id',
    [orderItemId],
    { autoCommit: true }
  );
  res.redirect('/orderItems');
} catch (err) {
  console.error(err);
  res.status(500).send('Error deleting order item');
} finally {
  if (connection) {
    try {
      await connection.close();
    } catch (err) {
      console.error(err);
    }
  }
}
});





//---------------------------------------------------
// Show orders
app.get('/orders', async (req, res) => {
  let connection;

  try {
    connection = await oracledb.getConnection(dbConfig);
    const result = await connection.execute('SELECT * FROM Orders', [], { fetchArraySize: 1000 });
    res.render('orders', { orders: result.rows });
  } catch (err) {
    console.error(err);
    res.status(500).send('Error fetching orders');
  } finally {
    if (connection) {
      try {
        await connection.close();
      } catch (err) {
        console.error(err);
      }
    }
  }
});

// Insert Order
app.post('/orders', async (req, res) => {
  const { customerId, status, paymentType, orderDate, shipDate, shipStreet, shipCity, shipState, shipZip, shipCost } = req.body;
  let connection;

  try {
    connection = await oracledb.getConnection(dbConfig);
    await connection.execute(
      'INSERT INTO Orders (OrderId, CustomerId, Status, PaymentType, OrderDate, ShipDate, ShipStreet, ShipCity, ShipState, ShipZip, ShipCost) VALUES (orderid_seq.NEXTVAL, :customerId, :status, :paymentType, :orderDate, :shipDate, :shipStreet, :shipCity, :shipState, :shipZip, :shipCost)',
      [customerId, status, paymentType, new Date(orderDate), new Date(shipDate), shipStreet, shipCity, shipState, shipZip, shipCost],
      { autoCommit: true }
    );
    res.redirect('/orders');
  } catch (err) {
    console.error(err);
    res.status(500).send('Error adding order');
  } finally {
    if (connection) await connection.close();
  }
});

// Update Order
app.post('/orders/update/:orderId', async (req, res) => {
  const orderId = req.params.orderId;
  const { customerId, status, paymentType, orderDate, shipDate, shipStreet, shipCity, shipState, shipZip, shipCost } = req.body;
  let connection;

  try {
    connection = await oracledb.getConnection(dbConfig);
    const query = `
      UPDATE Orders
      SET CustomerId = :customerId,
          Status = :status,
          PaymentType = :paymentType,
          OrderDate = :orderDate,
          ShipDate = :shipDate,
          ShipStreet = :shipStreet,
          ShipCity = :shipCity,
          ShipState = :shipState,
          ShipZip = :shipZip,
          ShipCost = :shipCost
      WHERE OrderId = :orderId
    `;
    const binds = {
      customerId,
      status,
      paymentType,
      orderDate: new Date(orderDate),
      shipDate: new Date(shipDate),
      shipStreet,
      shipCity,
      shipState,
      shipZip,
      shipCost,
      orderId
    };
    const result = await connection.execute(query, binds, { autoCommit: true });

    if (result.rowsAffected > 0) {
      console.log('Order updated successfully.');
      res.redirect('/orders');
    } else {
      console.log('Order not found.');
      res.status(404).send('Order not found');
    }
  } catch (err) {
    console.error('Error updating order:', err);
    res.status(500).send('Error updating order');
  } finally {
    if (connection) {
      try {
        await connection.close();
      } catch (err) {
        console.error(err);
      }
    }
  }
});

// Delete Order
app.post('/orders/delete/:orderId', async (req, res) => {
  const orderId = req.params.orderId;
  let connection;

  try {
    connection = await oracledb.getConnection(dbConfig);
    await connection.execute(
      'DELETE FROM Orders WHERE OrderId = :orderId',
      [orderId],
      { autoCommit: true }
    );
    res.redirect('/orders');
  } catch (err) {
    console.error(err);
    res.status(500).send('Error deleting order');
  } finally {
    if (connection) {
      try {
        await connection.close();
      } catch (err) {
        console.error(err);
      }
    }
  }
});


//---------------------------------------------------
// Show reviews
app.get('/reviews', async (req, res) => {
  let connection;

  try {
    connection = await oracledb.getConnection(dbConfig);
    const result = await connection.execute('SELECT * FROM Review', [], { fetchArraySize: 1000 });
    res.render('reviews', { reviews: result.rows });
  } catch (err) {
    console.error(err);
    res.status(500).send('Error fetching reviews');
  } finally {
    if (connection) {
      try {
        await connection.close();
      } catch (err) {
        console.error(err);
      }
    }
  }
});

// Insert Review
app.post('/reviews', async (req, res) => {
  const { orderId, customerId, productId, comments, rating } = req.body;
  let connection;

  try {
    connection = await oracledb.getConnection(dbConfig);
    await connection.execute(
      'INSERT INTO Review (ReviewId, OrderId, CustomerId, ProductId, Comments, Rating) VALUES (reviewid_seq.NEXTVAL, :orderId, :customerId, :productId, :comments, :rating)',
      [orderId, customerId, productId, comments, rating],
      { autoCommit: true }
    );
    res.redirect('/reviews');
  } catch (err) {
    console.error(err);
    res.status(500).send('Error adding review');
  } finally {
    if (connection) await connection.close();
  }
});

// Update Review
app.post('/reviews/update/:reviewId', async (req, res) => {
  const reviewId = req.params.reviewId;
  const { orderId, customerId, productId, comments, rating } = req.body;

  let connection;
  try {
    connection = await oracledb.getConnection(dbConfig);
    const query = `
      UPDATE Review
      SET OrderId = :orderId,
          CustomerId = :customerId,
          ProductId = :productId,
          Comments = :comments,
          Rating = :rating
      WHERE ReviewId = :reviewId
    `;
    const binds = { orderId, customerId, productId, comments, rating, reviewId: Number(reviewId) };
    const result = await connection.execute(query, binds, { autoCommit: true });
    
    if (result.rowsAffected > 0) {
      console.log('Review updated successfully.');
      res.redirect('/reviews');
    } else {
      console.log('Review not found.');
      res.status(404).send('Review not found');
    }
  } catch (err) {
    console.error('Error updating review:', err);
    res.status(500).send('Error updating review');
  } finally {
    if (connection) {
      try {
        await connection.close();
      } catch (err) {
        console.error(err);
      }
    }
  }
});

// Delete Review
app.post('/reviews/delete/:id', async (req, res) => {
  const reviewId = req.params.id;
  let connection;

  try {
    connection = await oracledb.getConnection(dbConfig);
    await connection.execute(
      'DELETE FROM Review WHERE ReviewId = :id',
      [reviewId],
      { autoCommit: true }
    );
    res.redirect('/reviews');
  } catch (err) {
    console.error(err);
    res.status(500).send('Error deleting review');
  } finally {
    if (connection) {
      try {
        await connection.close();
      } catch (err) {
        console.error(err);
      }
    }
  }
});

//---------------------------------------------------
// Show product
app.get('/products', async (req, res) => {
  let connection;

  try {
    connection = await oracledb.getConnection(dbConfig);
    const result = await connection.execute('SELECT * FROM Product', [], { fetchArraySize: 1000 }); // Adjust this to match your table name
    res.render('products', { products: result.rows });
  } catch (err) {
    console.error(err);
    res.status(500).send('Error fetching products');
  } finally {
    if (connection) {
      try {
        await connection.close();
      } catch (err) {
        console.error(err);
      }
    }
  }
});

// Insert Product
app.post('/products', async (req, res) => {
  // Extract data from the request
  const { title, cost, retail, category, description, status } = req.body;
  let connection;

  try {
    connection = await oracledb.getConnection(dbConfig);
    await connection.execute(
      'INSERT INTO Product (ProductId, Title, Cost, Retail, Category, Description, Status) VALUES (productid_seq.NEXTVAL, :title, :cost, :retail, :category, :description, :status)',
      [title, cost, retail, category, description, status],
      { autoCommit: true } // show more than 10 rows
    );
    res.redirect('/products');
  } catch (err) {
    console.error(err);
    res.status(500).send('Error adding product');
  } finally {
    if (connection) await connection.close();
  }
});

// Update Product
app.post('/products/update/:productId', async (req, res) => {
  const productId = req.params.productId;
  const { title, cost, retail, category, description, status } = req.body; // Extract all fields from the request body

  let connection;
  try {
    connection = await oracledb.getConnection(dbConfig);
    const query = `
      UPDATE Product
      SET Title = :title,
          Cost = :cost,
          Retail = :retail,
          Category = :category,
          Description = :description,
          Status = :status
      WHERE ProductId = :productId
    `;
    const binds = { title, cost: Number(cost), retail: Number(retail), category, description, status, productId: Number(productId) }; // Bind all values
    const result = await connection.execute(query, binds, { autoCommit: true });
    
    if (result.rowsAffected > 0) {
      console.log('Product updated successfully.');
      res.redirect('/products');
    } else {
      console.log('Product not found.');
      res.status(404).send('Product not found');
    }
  } catch (err) {
    console.error('Error updating product:', err);
    res.status(500).send('Error updating product');
  } finally {
    if (connection) {
      try {
        await connection.close();
      } catch (err) {
        console.error(err);
      }
    }
  }
});

// Delete Product
app.post('/products/delete/:id', async (req, res) => {
  const productId = req.params.id;
  let connection;

  try {
    connection = await oracledb.getConnection(dbConfig);
    await connection.execute(
      'DELETE FROM Product WHERE ProductId = :id',
      [productId],
      { autoCommit: true }
    );
    res.redirect('/products');
  } catch (err) {
    console.error(err);
    res.status(500).send('Error deleting product');
  } finally {
    if (connection) {
      try {
        await connection.close();
      } catch (err) {
        console.error(err);
      }
    }
  }
});


//---------------------------------------------------
// Home page route
app.get('/', (req, res) => res.render('index'));

// Listen on the defined port
app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});
